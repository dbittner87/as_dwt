import env

import multiprocessing as mp
import numpy as np
import os
import subprocess
import sys
import time as tm

### Parameter to choose
threads = 4
N = 400
scriptName = 'calc_template.py'
mode = 'good parallel' #'good parallel','bad parallel','serial'

### function for 'bad parallel'
def fun(command,i,N):
    print('\nstart subprocess (%i/%i): '%(i+1,N))
    subprocess.call(command,shell=True)
    print('subprocess (%i/%i) done\n'%(i+1,N))

### computation
if __name__ == '__main__':
    # timing
    start = tm.time()

    # working directory
    dir = env.dir_as_G_jacG
    os.system('mkdir -p %s' % dir)
    
    # compute parameter-samples
    samples = env.prior_sample(N)
    np.savetxt('%s/samples.txt' % dir, samples)

    # compute model-samples
    ### serial by Mario Parente (added log- and errorfiles by Michael Engel)
    if mode == 'serial':
        print(mode)
        print('start serial sampling for '+str(N)+' samples')
        print('>>> mind that log- and error-file need ~'+str(30*N)+'KB in RAM')
        cmds = ''
        for i in range(N):
            sample = samples[i]
            cmd = sys.executable + " " + scriptName + " " + \
                str(i) + " " + ' '.join(str(p) for p in sample)
            cmds += cmd + '\n'
        
        batFile = '%s\\calc_runs.bat' % dir
        logFile = ' >%s\\log.txt' % dir
        errorFile = ' 2>%s\\error.txt' % dir
        with open(batFile, 'w') as file:
            file.write(cmds)
        
        subprocess.call(batFile+logFile+errorFile, shell=True)
        
    ### parallel by Michael Engel (not the best way, but one can see the progress of the calculation) 
    elif mode == 'bad parallel':
        print(mode)
        # check the amount of threads
        if threads > N:
            threads = N
        threads = max(min(threads, mp.cpu_count()), 1)
        
        print('start parallel sampling for '+str(max(min(threads,mp.cpu_count()),1))+' threads and '+str(N)+' samples')
        
        # compute commands i for the threads
        commands = []
        for i in range(N):
            sample = samples[i]
            cmd = sys.executable + " " + scriptName + " " + \
                str(i) + " " + ' '.join(str(p) for p in sample)
            commands.append(cmd)
        
        # set up pool and start calculation
        pool = mp.Pool(threads)
        tuplearray = [(commands[i],i,N) for i in range(N)]
        results = pool.starmap(fun,tuplearray)
        pool.close()
        pool.join()
        
    ### parallel by Maximilian Peisl and Michael Engel (special thanks for the support by Maximilian Peisl)
    elif mode == 'good parallel':
        print(mode)
        # check the amount of threads
        if threads > N:
            threads = N
        threads = max(min(threads, mp.cpu_count()), 1)
        
        print('start parallel sampling for ' + str(max(min(threads, mp.cpu_count()), 1)) + ' threads and ' + str(N) + ' samples')
        print('>>> mind that log- and error-files need ~'+str(30*N)+'KB in RAM')
    
        # compute sample-intervals for partitioning
        intervals = np.empty(threads + 1)
        intervals[0] = 0
        intervals[threads] = N
        tmp = int(np.floor(N / threads))
        for i in range(1, threads):
            intervals[i] = i*tmp
    
        # set up and start threads
        for k in range(threads):
            # compute the commands i for the thread k
            cmds = ''
            for i in range(int(intervals[k]), int(intervals[k+1])):
                sample = samples[i]
                cmd = sys.executable + " " + scriptName + " " + \
                    str(i) + " " + ' '.join(str(p) for p in sample)
                cmds += cmd + '\n'
            # bat-, log- and error-files for thread k
            batFile = '%s\\calc_runs_kernel%i.bat' %(dir,k)
            logFile = ' >%s\\log_%i.txt' %(dir,k)
            errorFile = ' 2>%s\\error_%i.txt' %(dir,k)
            with open(batFile, 'w') as file:
                file.write(cmds)
            # start subprocess k
            if k == threads-1:
                print('\tstart subprocess %i'%k)
                subprocess.call(batFile+logFile+errorFile, shell=True)
                print('\tfinished subprocesses')
            else:
                print('\tstart subprocess %i'%k)
                subprocess.Popen(batFile+logFile+errorFile, shell=True)
    else:
        print('mode "%s" not defined'%mode)

    print('calc_parallel.py done after: '+str(tm.time()-start)+'s')