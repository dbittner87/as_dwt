### Michael Engel ### 13.11.2019 ### MEdatascale.py ###
from misc import Settings
from MEwavelet import*
import numpy as np
import matplotlib.pyplot as plt

settings = Settings('settings')
_s = settings

noise_level = _s.noiseLevel

scenario = _s.scenario
scenario_dir = 'scens/' + _s.scenario
data_dir = _s.data_dir
scenario_data_dir = '/'.join([data_dir, scenario])

_s_scen = Settings('/'.join([scenario_dir, settings.scenario_settings_file]))
scen_exe = '/'.join([scenario_dir, _s_scen.exe])

data_file = '/'.join([scenario_dir, _s_scen.data_file])
data_time = np.loadtxt(data_file, comments='"')
data_time = MEsignal2log2signal1D(data_time)
data_time = data_time-np.mean(data_time)
#data_time = data_time[:64]
maxi = int(np.log2(len(data_time)))
print('data done')

coeffs = MEsignal2coeffs1D(data_time,motherfct='db1',mode='zero',maxlevel=maxi)

for i in range(maxi+1):
    np.savetxt(scenario_dir+'\data_scale_%i'%i,coeffs[i])

print('data in scales done')