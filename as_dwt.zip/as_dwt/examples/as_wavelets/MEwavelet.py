### Michael Engel ### 03.10.2019 ### MEwavelet.py ###
import numpy as np
from numpy import pi
from scipy import linalg
import random
import matplotlib.pyplot as plt
import pywt
import copy

### tools

def MEdeldup(indices, typ='list'):
    if typ == 'list':
        return list(dict.fromkeys(indices))
    elif typ == 'array':
        return np.array(list(dict.fromkeys(indices)))
    else:
        return 0
    
def MEmarkdup(indices, typ='list'):
    pass

def MEmatinv(mat):
    L = linalg.cholesky(mat,lower=True)
    L_inv = np.linalg.inv(L)
    return np.array(np.mat(L_inv).T*np.mat(L_inv))

def MEwmi(cov,motherfct='db1',order='downscale'):
    length = len(cov)
    Gamma = np.mat(cov)
    Gammahat= np.mat(MEcoeffrho2coeffrhohat1D(cov,range(len(cov)),motherfct=motherfct,order=order))
    signdetGamma, logdetGamma = np.linalg.slogdet(Gamma)
    signdetGammahat, logdetGammahat = np.linalg.slogdet(Gammahat)
    WMI = 0.5*((np.log(signdetGammahat)+logdetGammahat)-(np.log(signdetGamma)+logdetGamma)+np.trace(Gamma*Gammahat.I)-length)
    H = 0.5*(length*(1+np.log(2*pi))+np.log(signdetGamma)+logdetGamma)
    Hhat = 0.5*(length*(1+np.log(2*pi))+np.log(signdetGammahat)+logdetGammahat)
    NWMI = WMI/np.sqrt(H*Hhat)
    return WMI, NWMI

### signal2...
    
def MEsignal2log2signal1D(signal):
    exponent = np.floor(np.log2(len(signal)))
    return signal[:int(2**exponent)]
    
def MEsignal2signals1D (signal,motherfct='db1',mode='periodic',maxlevel=None):
    if maxlevel == None:
        maxlevel = pywt.dwt_max_level(len(signal), motherfct)
    coeffs = pywt.wavedec(signal, wavelet=motherfct, mode=mode, level=maxlevel)

    signals = [signal]
    for i in range(0,maxlevel+1):
        coeff_level = copy.deepcopy(coeffs)
        for j in range(0,maxlevel+1):
            if j != i:
                coeff_level[j] = np.zeros_like(coeff_level[j])
        signals.append(pywt.waverec(coeff_level,motherfct, mode = mode))
    return signals

def MEsignal2signals2D (signal,motherfct='db1',mode='periodic',maxlevel=None):
    if maxlevel == None:
        maxlevel = pywt.dwtn_max_level(np.shape(signal), motherfct)
    coeffs = pywt.wavedec2(signal, wavelet=motherfct, mode=mode, level=maxlevel, axes=(-2, -1))

    signals = [signal]
    for i in range(0,maxlevel+1):
        coeff_level = copy.deepcopy(coeffs)
        for j in range(0,maxlevel+1):
            if j != i:
                coeff_level[j] = tuple([np.zeros_like(v) for v in coeff_level[j]])
        signals.append(pywt.waverec2(coeff_level,motherfct, mode = mode))
    return signals

def MEsignal2coeffs1D(signal,motherfct='db1',mode='periodic',maxlevel=None):
    if maxlevel == None:
        maxlevel = pywt.dwt_max_level(len(signal), motherfct)
    coeffs = pywt.wavedec(signal, wavelet=motherfct, mode=mode, level=maxlevel)
    return coeffs

def MEsignal2coeffs2D(signal,motherfct='db1',mode='periodic',maxlevel=None):
    if maxlevel == None:
        maxlevel = pywt.dwtn_max_level(np.shape(signal), motherfct)
    coeffs = pywt.wavedec2(signal, wavelet=motherfct, mode=mode, level=maxlevel, axes=(-2, -1))
    return coeffs

def MEsignal2coeffssignal1D(signal,motherfct='db1',mode='periodic',maxlevel=None,order='downscale',seed=None):
    return MEcoeffs2coeffssignal1D(MEsignal2coeffs1D(signal,motherfct,mode,maxlevel),order,seed)


### coeffs2...
    
def MEcoeffs2coeffssignal1D(coeffs, order='downscale', seed=None):
    coeffssignal = []
    if order == 'downscale':
        for i in range(len(coeffs)):
            coeffssignal.extend(coeffs[i])
            
    elif order == 'upscale':
        for i in range(len(coeffs)):
            coeffssignal.extend(coeffs[-(i+1)])
            
    elif order == 'random':
        for i in range(len(coeffs)):
            coeffssignal.extend(coeffs[i])
        if seed == None:
            random.seed()
        else:
            random.seed(seed)
        random.shuffle(coeffssignal)
        
    else:
        return 0
    return coeffssignal

def MEcoeffs2signals1D(coeffs,motherfct='db1',mode='periodic',maxlevel=None):
    if maxlevel == None:
        maxlevel = pywt.dwt_max_level(len(MEcoeffs2coeffssignal1D(coeffs)), motherfct)
        
    signals = [pywt.waverec(coeffs,motherfct,mode)]
    for i in range(0,maxlevel+1):
        coeff_level = copy.deepcopy(coeffs)
        for j in range(0,maxlevel+1):
            if j != i:
                coeff_level[j] = np.zeros_like(coeff_level[j])
        signals.append(pywt.waverec(coeff_level,motherfct, mode = mode))
    return signals

def MEcoeffs2signal1D(coeffs,motherfct='db1',mode='periodic',maxlevel=None):
    return pywt.waverec(coeffs,motherfct,mode)


### coeffssignal2...
    
def MEcoeffssignal2coeffs1D(coeffssignal, motherfct='db1', mode='periodic', order='downscale', seed=None):
    if motherfct == 'db1' or mode == 'periodization':
        maxlevel = int(np.log2(len(coeffssignal)))
        if order == 'downscale':
            coeffs = [np.array([coeffssignal[0]])]
            for k in range(1,maxlevel+1):
                coeffs.append(np.array(coeffssignal[int(2**(k-1)):int(2**k)]))
                
        elif order == 'upscale':
            coeffs = [np.array([coeffssignal[-1]])]
            for k in range(1,maxlevel+1):
                coeffs.append(np.array(coeffssignal[-int(2**k):-int(2**(k-1))]))
                
        elif type(order)==list:
            coeffs_ = np.zeros(len(coeffssignal))
            for i in range(len(coeffssignal)):
                coeffs_[i]=coeffssignal[order[i]]
            coeffs = [np.array([coeffs_[0]])]
            for k in range(1,maxlevel+1):
                coeffs.append(np.array(coeffs_[int(2**(k-1)):int(2**k)]))
        else:
            return 0
    else:
        return 0
    return coeffs

def MEcoeffssignal2signals1D(coeffssignal,motherfct='db1',mode='periodic',maxlevel=None,order='downscale',seed=None):
    return MEcoeffs2signals1D(MEcoeffssignal2coeffs1D(coeffssignal,motherfct,mode,order,seed),motherfct,mode,maxlevel)

def MEcoeffssignal2signal1D(coeffssignal,motherfct='db1',mode='periodic',maxlevel=None,order='downscale',seed=None):
    return MEcoeffs2signal1D(MEcoeffssignal2coeffs1D(coeffssignal,motherfct,mode,order,seed),motherfct,mode,maxlevel)

def MEcoeffssignal2index1D(coeffssignal,motherfct='db1',mode='periodic',maxlevel=None,order='downscale',seed=None):
    if motherfct == 'db1' or mode == 'periodization':
        if maxlevel == None:
            maxlevel = int(np.log2(len(coeffssignal)))
        if order == 'downscale':
            index = [np.array([0,0])]
            for k in range(1,maxlevel+1):
                for v in range(0,2**(k-1)):
                    index.append(np.array([k,v]))
        elif order == 'upscale':
            index = [np.array([0,0])]
            for k in range(1,maxlevel+1):
                for v in range(0,2**(k-1)):
                    index.append(np.array([k,v]))
                index[2**(k-1):2**k]=index[2**(k-1):2**k][::-1]
            index = index[::-1]
        elif type(order)==list:
            pass
    else:
        return 0
    return index                    

### cov and rho
    
def MEcoeffrho2coeffrhohat1D(rho,coeffssignal,motherfct='db1',mode='periodic',order='downscale',seed=None):   # works for cov too as only values are copied
    rho_ = np.zeros(np.shape(rho))
    if motherfct == 'db1' or mode == 'periodization':
        maxlevel = int(np.log2(len(coeffssignal)))
        if order == 'downscale':
            rho_[0,0]=rho[0,0]
            for k in range(1,maxlevel+1):
                rho_[int(2**(k-1)):int(2**k),int(2**(k-1)):int(2**k)] = rho[int(2**(k-1)):int(2**k),int(2**(k-1)):int(2**k)]
                
        elif order == 'upscale':
            rho_[-1,-1]=rho[-1,-1]
            for k in range(1,maxlevel+1):
                rho_[-int(2**k):-int(2**(k-1)),-int(2**k):-int(2**(k-1))] = rho[-int(2**k):-int(2**(k-1)),-int(2**k):-int(2**(k-1))]
                
        elif type(order)==list:
            pass
        else:
            return 0
    else:
        return 0
    return rho_

def MEcoeffcov2coeffcovhat1D(cov,coeffssignal,motherfct='db1',order='downscale',seed=None):
    return MEcoeffrho2coeffrhohat1D(cov,coeffssignal,motherfct='db1',order='downscale',seed=None)

def MEcov2coeffcov1D(cov,motherfct='db1',mode='periodic',maxlevel=None,order='downscale',seed=None):
    if motherfct == 'db1':
        if maxlevel == None:
            maxlevel = int(np.log2(len(cov)))

        def G(l):
            g = np.array([1/np.sqrt(2),-1/np.sqrt(2)])
            return linalg.block_diag(*([g]*int(2**(l-1))))
        def PIG(j):
            pig = np.eye(2**maxlevel)
            for l in range(0,maxlevel-j):
                pig = np.mat(G(maxlevel-l))*np.mat(pig)
            return pig
        def H(j):
            h = np.array([1/np.sqrt(2),1/np.sqrt(2)])
            if j == 0:
                return G(j)
            else:
                return linalg.block_diag(*([h]*int(2**(j-1))))
        
        coeffcov = -np.ones(np.shape(cov))
        H_ = [G(1)]
        H_.extend([H(j) for j in range(1,maxlevel+1)])
        PIG_ = [PIG(1)]
        PIG_.extend([PIG(j) for j in range(1,maxlevel+1)])
        for j in range(0,maxlevel+1):
            if j == 0:
                limi = 1
            else:
                limi = int(2**(j-1))
            H_j = H_[j]
            PIG_j = PIG_[j]
            for i in range(0,limi):
                H_ji = H_j[i,:]
                for u in range(0,maxlevel+1):
                    if u == 0:
                        limu = 1
                    else:
                        limu = int(2**(u-1))
                    H_u = H_[u]
                    PIG_u = PIG_[u]
                    for w in range(0,limu):
                        H_uw = H_u[w,:]
                        if j == 0:
                            limi = 0
                        if u == 0:
                            limu = 0
                        coeffcov[limi+i,limu+w]=np.mat(H_ji)*np.mat(PIG_j)*np.mat(cov)*(np.mat(H_uw)*np.mat(PIG_u)).T
        if order == 'downscale':
            pass
        elif order == 'upscale':
            def bidict(lista):
                dictb = {}
                j = 0
                for i in lista:
                    dictb[tuple(i)]=j
                    dictb[j]=tuple(i)
                    j=j+1
                return dictb
            downscaleindex = MEcoeffssignal2index1D(range(len(cov)),motherfct,mode,maxlevel,'downscale',seed)
            orderindex = MEcoeffssignal2index1D(range(len(cov)),motherfct,mode,maxlevel,order,seed)
            orderdict = bidict(orderindex)
            downscaledict = bidict(downscaleindex)
            newdict = {}
            for i in range(len(cov)):
                newdict[i]=orderdict[downscaledict[i]]
            coeffcovcopy = copy.deepcopy(coeffcov)
            for i in range(len(cov)):
                for j in range(len(cov)):
                    coeffcov[i,j]=coeffcovcopy[newdict[i],newdict[j]]
        return np.array(coeffcov)
    else:
        return 0
    
def MEcov2invcoeffcov1D(cov,motherfct='db1',mode='periodic',maxlevel=None,order='downscale',seed=None):
    invcov = MEmatinv(cov)
    return MEcov2coeffcov1D(invcov,motherfct,mode,maxlevel,order,seed)

def MEcov2rho1D(cov):
    var = np.diag(cov)
    sqdiag = np.diag(np.reciprocal(np.sqrt(var)))
    rho = np.mat(sqdiag)*(np.mat(cov)*np.mat(sqdiag))
    return rho
            
    
### haar-wavelets (not validated)
    
def MErhovec(signal,motherfct='db1',mode='zero',maxlevel=None):
    if maxlevel == None:
        maxlevel = pywt.dwtn_max_level(np.shape(signal), motherfct)
    elif 2**maxlevel > len(signal):
        maxlevel = int(np.log2(len(signal)))
    
    if motherfct == 'db1' and mode == 'zero':
        rhovec = np.zeros([len(signal),len(signal),maxlevel+1])
        for i in range(0,maxlevel+1):
            if i == 0:
                local = np.ones([len(signal),len(signal)])+np.diag(1e-15*np.ones(len(signal)))  #adding of noise for full rank
            else:
                local = np.ones([int(len(signal)/2**(i-1)),int(len(signal)/2**(i-1))])+np.diag(1e-15*np.ones(int(len(signal)/2**(i-1)))) #adding of noise for full rank
                local[int(len(local)/2):,:int(len(local)/2)]=-1
                local[:int(len(local)/2),int(len(local)/2):]=-1
            for j in range(int(len(signal)/len(local))):
                rhovec[j*len(local):(j+1)*len(local),j*len(local):(j+1)*len(local),i] = local
    else:
        print('### MErhovec: no rhovec provided for that input ###')
        return 0
    return rhovec

def MErhovecinv(rhovec): # also works for gamma
    rhovecinv = np.zeros(np.shape(rhovec))
    for i in range(np.shape(rhovec)[2]):
        L = linalg.cholesky(rhovec[:,:,i],lower=True)
        L_inv = np.linalg.inv(L)
        rhovecinv[:,:,i] = np.mat(L_inv).T*np.mat(L_inv)
    return rhovecinv

def MEgammavec(varvec,rhovec):
    gammavec = np.zeros([np.shape(rhovec)[0],np.shape(rhovec)[0],np.shape(varvec)[1]])
    for i in range(np.shape(varvec)[1]):
        sqdiag = np.diag(np.sqrt(varvec[:,i]))
        gammavec[:,:,i] = np.mat(sqdiag)*(np.mat(rhovec[:,:,i])*np.mat(sqdiag))
    return gammavec

def MEgammavecinv(varvec,rhovecinv):
    gammavecinv = np.zeros([np.shape(rhovecinv)[0],np.shape(rhovecinv)[0],np.shape(varvec)[1]])
    for i in range(np.shape(varvec)[1]):
        sqindiag = np.diag(np.reciprocal(np.sqrt(varvec[:,i]))) ### reciprocal might be wrong as from rho to gamma and not vice versa
        gammavecinv[:,:,i] = np.mat(sqindiag)*(np.mat(rhovecinv[:,:,i])*np.mat(sqindiag))
    return gammavecinv

def MEhaar1D(y,maxlevel=None,coeffs=None):
    if coeffs == None:
        coeffs = []    
    if maxlevel == None:
        maxlevel = np.log2(len(y))-1
    else:
        maxlevel = maxlevel-1
        
    H = np.zeros([int(len(y)/2),len(y)])
    G = np.zeros([int(len(y)/2),len(y)])
    for i in range(int(len(y)/2)):
        H[i,i*2:i*2+2] = 1
        G[i,i*2]=1
        G[i,i*2+1]=-1
    W = 1/np.sqrt(2)*np.concatenate((H,G))
    
    y = np.mat(y)
    if np.shape(y) != (len(y),1):
        result = np.array(np.mat(W)*np.mat(y).T)
    else:
        result = np.array(np.mat(W)*np.mat(y))
        
    coeffs.append(result[int(len(result)/2):,0])
    if maxlevel == 0:
        coeffs.append(result[:int(len(result)/2),0])
    elif len(result)/2>=2:
        MEhaar1D(result[:int(len(result)/2),0],maxlevel=maxlevel,coeffs=coeffs)
    else:
        coeffs.append(result[0,0])
    return coeffs[::-1]