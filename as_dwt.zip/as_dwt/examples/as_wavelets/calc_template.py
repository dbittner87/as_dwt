import env
import model

import numpy as np
import numpy.linalg as la
import sys


# dir = 'tmp_misfits_G'
# dir = 'tmp_post_G_%id_%.2f' % (env.k, env.noise_level)
dir = env.dir_as_G_jacG


def run(id, sample):
    print("Sample %i" % id)

    m = model.Model(id, sample)

    # qoi = m.getQoI()
    # np.savetxt('%s/G%i.txt' % (dir, id), qoi)

    qoi = m.getQoI()
    jacs = m.getJacobians()
    
    for i in range(env.n_scales+1):
        np.savetxt('%s/scale_%i/G%i.txt' % (dir, i, id), qoi[i])
        np.savetxt('%s/scale_%i/jacG%i.txt' % (dir, i, id), jacs[i])


def usage():
    print("usage: id parameters")


if __name__ == "__main__":
    if len(sys.argv) == env.n + 2:
        run(int(sys.argv[1]), np.array(sys.argv[2:], dtype=float))
    else:
        usage()
