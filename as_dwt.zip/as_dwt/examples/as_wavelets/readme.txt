I. Umgebungsvariablen einsetzen
II. Pfade anpassen in settings-file (for the AS code) and in main_exe.R (for the model of the chosen scenario) und sicherstellen, dass genügend Ordner für die Skalen vorhanden sind.
III. Diskretisierungsschritt für Gradientenbestimmung in model.py-file: getJacobians passend wählen.
IV. settings überprüfen
V. env.py überprüfen
VI. MEdatascale.py
VII. MEinvNoiseCovMat_coeff.py
VII. calc_parallel.py
VIII. calc_as.py
IX. plot_as.py
X. calc_regr.py
XI. env.py anpassen
XII. run_as_MCMC.py