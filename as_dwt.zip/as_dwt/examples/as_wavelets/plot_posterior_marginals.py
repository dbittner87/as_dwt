import env

import numpy as np
import numpy.random as rnd
import matplotlib.pyplot as plt
import seaborn as sns


def plot_posterior_marginals(scale=1):
    dir_mcmc = env.mcmc_dir
    k = env.ks[scale]

    x_samples = np.loadtxt('%s/scale_%i/x_samples_%id.txt' % (dir_mcmc,scale,k))

    params = np.array([5, 12, 19])
    params = np.array(range(21))
    choice = rnd.choice(len(x_samples), 30000)

    x_samples = x_samples[choice][:, params-1]

    bins = 20

    for i in range(len(params)):
        plt.figure()
        sns.distplot(x_samples[:, i], kde=False, hist=True, norm_hist=True, bins=bins,
                     hist_kws={"linewidth": 0, "alpha": 1})
        plt.xlim((-1, 1))
        plt.xlabel(r'$\mathbf{x}_{%i}$' % params[i])
        plt.ylabel('Posterior prob.')
        plt.title('scale %i'%scale)


if __name__ == '__main__':
#    for i in range(env.n_scales+1):
    for i in range(3,4):
        plot_posterior_marginals(i)
        print(i)
    plt.show()
