import env
import plotters
from uq_tools import asm
from uq_tools import utils

settings = env.settings

nBoot = settings.numberBootstrapIterations

prefix = None

for i in range(env.n_scales+1):
    as_dir = "%s\\scale_%i" % (env.as_dir,i)
    result = asm.computeActiveSubspaceFromSamples(env.Gss[i], env.jacGss[i], env.bayInvPbs[i], nBoot)

    eigVals, eigVecs, minEigVals, maxEigVals, minSubspaceErrors, maxSubspaceErrors, meanSubspaceErrors = result
    
    utils.save_active_subspace(eigVals, eigVecs, minEigVals, maxEigVals,
                               minSubspaceErrors, maxSubspaceErrors, meanSubspaceErrors,
                               dir=as_dir, prefix=prefix)

#numPlotEigVals = 9
#plotters.plotActiveSubspace(eigVals, eigVecs, numPlotEigVals, minEigVals, maxEigVals,
#                            minSubspaceErrors, maxSubspaceErrors, meanSubspaceErrors)
