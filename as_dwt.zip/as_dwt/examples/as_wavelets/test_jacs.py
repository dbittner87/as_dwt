import env
import model

import numpy as np
import time as tm


parameters = [0., 0., 0., 0., 0., 0., 0.,
              0., 0., 0., 0., 0., 0., 0.,
              0., 0., 0., 0., 0., 0., 0.]

# m = model.AbstractModel().instantiate(parameters)
m = model.Model(-1, parameters)

t0 = tm.time()
jacs = m.getJacobians()
print(tm.time()-t0)

print(np.shape(jacs))
if np.shape(jacs)==(env.n_scales,env.n_timeseries,env.n):
    print('YES!')

for i in range(env.n_scales):
    print(np.allclose(jacs[i], 0))
