import env
from uq_tools.gradients import cfd

import numpy as np
import subprocess

from watrans import Watrans
from padded import padded
from MEwavelet import*


_settings = env.settings


class Model:
    def __init__(self, id, parameters):
        self.id = id
        self.parameters = parameters

        self.parameters_model = \
            env.fromCalibrationToPhysicalParameters([parameters]).flatten()
        [self.k_e_2_num, self.e_min_2, self.e_max_2, self.alpha_2, self.k_is_2, self.k_sec_2, self.e_sec_2,
         self.k_e_3_num, self.e_min_3, self.e_max_3, self.alpha_3, self.k_is_3, self.k_sec_3, self.e_sec_3,
         self.k_e_4_num, self.e_min_4, self.e_max_4, self.alpha_4, self.k_is_4, self.k_sec_4, self.e_sec_4] \
            = self.parameters_model

    def getQoI(self):
        if hasattr(self, 'qoi'):
            return self.qoi
        print('Rscript.exe %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f' %
                  (env.scen_exe, self.id,
                   self.k_e_2_num, self.e_min_2, self.e_max_2, self.alpha_2, self.k_is_2, self.k_sec_2, self.e_sec_2,
                   self.k_e_3_num, self.e_min_3, self.e_max_3, self.alpha_3, self.k_is_3, self.k_sec_3, self.e_sec_3,
                   self.k_e_4_num, self.e_min_4, self.e_max_4, self.alpha_4, self.k_is_4, self.k_sec_4, self.e_sec_4))
        subprocess.run('Rscript.exe %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f' %
                  (env.scen_exe, self.id,
                   self.k_e_2_num, self.e_min_2, self.e_max_2, self.alpha_2, self.k_is_2, self.k_sec_2, self.e_sec_2,
                   self.k_e_3_num, self.e_min_3, self.e_max_3, self.alpha_3, self.k_is_3, self.k_sec_3, self.e_sec_3,
                   self.k_e_4_num, self.e_min_4, self.e_max_4, self.alpha_4, self.k_is_4, self.k_sec_4, self.e_sec_4),
                   shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        result = np.loadtxt('%s/output_%s.txt' %
                            (_settings.modelOutputDir, self.id),
                            comments='"')
        
        # TODO        
        result = MEsignal2log2signal1D(result)
        result = result-env.datamean
        coeffs = MEsignal2coeffs1D(result,motherfct='db1',mode='zero',maxlevel=env.n_scales)

        self.qoi = coeffs
        #self.qoi = np.ones((env.n_scales, env.n_timeseries))

        return self.qoi

    def getJacobians(self):
        if hasattr(self, 'jacs'):
            return self.jacs

        def G(x):
            pb = Model('%d_%d' % (self.id, hash(str(x))), x)
            return pb.getQoI()

        # print "Jac:%d" % (self.id)
        # return [0.]
        
        #self.jacs = np.empty((env.n_scales+1,env.n_timeseries, env.n))
        self.jacs = list(np.empty(env.n_scales+1))
        for j in range(env.n_scales+1):
            if j == 0:
                self.jacs[j] = np.zeros([1,env.n])
            else:
                self.jacs[j] = np.zeros([2**(j-1),env.n])
        
        h = 1e-4
        
        i = 0
        for h_ in np.multiply(np.eye(env.n), h):
            #i = 0 ### why the i here???
            Gx_left = G(self.parameters-h_)
            Gx_right = G(self.parameters+h_)
            print('\n\njacs: %i/%i'%(i+1,env.n))
            for j in range(env.n_scales+1):
                Gx_j_left = Gx_left[j]
                Gx_j_right = Gx_right[j]
                for k in range(len(Gx_j_left)):
                    self.jacs[j][k,i] = (Gx_j_left[k]-Gx_j_right[k])/(2*h)
            i += 1

        return self.jacs


class AbstractModel:
    def __init__(self):
        pass

    def instantiate(self, parameters, id=None):
        if id is None:
            id = hash(str(parameters))
        return Model(id, parameters)
