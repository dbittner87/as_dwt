from watrans import Watrans
import env
import numpy as np

data_full = env.data_full

watransOBJ = Watrans(data_full,'db10',3,1,'day','Testcase')
data_scales = np.array(watransOBJ.signal_normed_level[1:5])

for i in range(env.n_scales+1):
    np.savetxt("%s/data_scale_%i" % (env.scenario_dir,i), data_scales[i])