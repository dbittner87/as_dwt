### Michael Engel ### 08.11.2019 ### MEinvNoiseCovMat_coeff.py ###
from misc import Settings
from MEwavelet import*
import numpy as np
import matplotlib.pyplot as plt

### Parameters to choose
mode = 'constant' #'constant','variable'
constantvar = 3
noise_level = 0.05

### calculation
settings = Settings('settings')
_s = settings

scenario = _s.scenario
scenario_dir = 'scens/' + _s.scenario
data_dir = _s.data_dir
scenario_data_dir = '/'.join([data_dir, scenario])

_s_scen = Settings('/'.join([scenario_dir, settings.scenario_settings_file]))
scen_exe = '/'.join([scenario_dir, _s_scen.exe])

data_file = '/'.join([scenario_dir, _s_scen.data_file])
data_time = np.loadtxt(data_file, comments='"')
data_time = MEsignal2log2signal1D(data_time)
#data_time = data_time[:128]
maxi = int(np.log2(len(data_time)))
print('data done')

if mode == 'variable':
    variance = np.square(data_time * noise_level)
    NoiseCovMat_time = np.diag(variance)
    print('cov done')
    NoiseCovMat_coeff = MEcov2coeffcov1D(NoiseCovMat_time,motherfct='db1',mode='zero',maxlevel=maxi,order='downscale',seed=None)
    print('coeffcov done')
    invNoiseCovMat_coeff = MEcov2invcoeffcov1D(NoiseCovMat_time,motherfct='db1',mode='zero',maxlevel=maxi,order='downscale',seed=None)
    print('invcoeffcov done')
elif mode == 'constant':
    variance = np.square(constantvar*np.ones(np.shape(data_time)))
    NoiseCovMat_time = np.diag(variance)
    print('cov done')
    NoiseCovMat_coeff = NoiseCovMat_time
    print('coeffcov done')
    invNoiseCovMat_coeff = np.diag(np.reciprocal(variance))
    print('invcoeffcov done')
else:
    print('mode not defined')

np.savetxt('_invNoiseCovMat_coeff',invNoiseCovMat_coeff)
np.savetxt('_NoiseCovMat_coeff',NoiseCovMat_coeff)
print('DONE')

plt.figure()
plt.subplot(1,2,1)
plt.contourf(NoiseCovMat_coeff)
plt.title('Covariance Matrix')
plt.subplot(1,2,2)
plt.contourf(NoiseCovMat_coeff-np.diag(np.diag(NoiseCovMat_coeff)))
plt.title('without diagonal')
plt.figure()
plt.subplot(1,2,1)
plt.contourf(invNoiseCovMat_coeff)
plt.title('Inverse Covariance Matrix')
plt.subplot(1,2,2)
plt.contourf(invNoiseCovMat_coeff-np.diag(np.diag(invNoiseCovMat_coeff)))
plt.title('without diagonal')

WMI,NWMI = MEwmi(NoiseCovMat_coeff)
print('WMI: '+str(WMI)+'\nNWMI: '+str(NWMI))