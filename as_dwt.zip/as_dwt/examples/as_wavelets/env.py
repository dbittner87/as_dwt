from misc import Settings

from uq_tools import bayinv as bi

from glob import glob
import natsort
import numpy as np
import numpy.random as rnd
import os

from MEwavelet import*


settings = Settings('settings')
_s = settings

noise_level = _s.noiseLevel

scenario = _s.scenario
scenario_dir = 'scens\\' + _s.scenario
data_dir = _s.data_dir
scenario_data_dir = '\\'.join([data_dir, scenario])
dir_as_G_jacG = '/'.join([scenario_data_dir, _s.dir_as_G_jacG])
as_dir = '\\'.join([scenario_data_dir, _s.prefix_as_dir]) # + ("_%.2f" % noise_level)])
mcmc_dir = '\\'.join([scenario_data_dir, _s.mcmc_dir])
dir_misfits = '\\'.join([scenario_data_dir, _s.dir_misfits])
#os.system('mkdir -p %s && mkdir -p %s && mkdir -p %s' % (dir_as_G_jacG, as_dir, mcmc_dir))

samples_dir = dir_as_G_jacG

n = 21


# scenario settings
_s_scen = Settings('\\'.join([scenario_dir, settings.scenario_settings_file]))
scen_exe = '\\'.join([scenario_dir, _s_scen.exe])

data_full_file = '\\'.join([scenario_dir, _s_scen.data_file])
data_time = np.loadtxt(data_full_file, comments='"')
data_time = MEsignal2log2signal1D(data_time)
datamean = np.mean(data_time)
data_time = data_time-datamean

env_scen = __import__('scens.%s.env' % scenario, fromlist=['object'])
fromCalibrationToInterimParameters = env_scen.fromCalibrationToInterimParameters
fromInterimToCalibrationParameters = env_scen.fromInterimToCalibrationParameters
fromCalibrationToPhysicalParameters = env_scen.fromCalibrationToPhysicalParameters
fromPhysicalToCalibrationParameters = env_scen.fromPhysicalToCalibrationParameters


def prior_sample(N=None):
    return rnd.uniform(low=-1, high=1, size=(N, n)) if N != None \
        else rnd.uniform(low=-1, high=1, size=n)


def prior(x):
    return 2**-n if np.all(np.logical_and(x <= 1, x >= -1)) else 0


data_full = MEsignal2log2signal1D(np.loadtxt(data_full_file, comments='"'))

n_scales = _s.n_scales
poly_order = _s.poly_order

bayInvPbs = [None]*(n_scales+1)

_invNoiseCovMat = np.loadtxt('_invNoiseCovMat_coeff')
_NoiseCovMat = np.loadtxt('_NoiseCovMat_coeff')

for i in range(n_scales+1):
    if i == 0 or i == 1:
        data_i = np.array([[np.loadtxt("%s/data_scale_%i" % (scenario_dir,i), comments='"')]])
    else:
        data_i = np.loadtxt("%s/data_scale_%i" % (scenario_dir,i), comments='"')
    if i == 0:
        #_invNoiseCovMat_i = np.array([[_invNoiseCovMat[0,0]]])
        _invNoiseCovMat_i = MEmatinv(np.array([[_NoiseCovMat[0,0]]]))
    elif i == 1:
        #_invNoiseCovMat_i = np.array([[_invNoiseCovMat[1,1]]])
        _invNoiseCovMat_i = MEmatinv(np.array([[_NoiseCovMat[1,1]]]))
    else:
        #_invNoiseCovMat_i = _invNoiseCovMat[2**(i-1):2**i,2**(i-1):2**i] ### has to be checked!!!
        _invNoiseCovMat_i = MEmatinv(np.array(_NoiseCovMat[2**(i-1):2**i,2**(i-1):2**i]))
    
    bayInvPbs[i] = bi.BayesianInverseProblem(data_i, _invNoiseCovMat_i)

misfitGs = [bip.misfitG for bip in bayInvPbs]

### comment out first run
xs = np.loadtxt('%s/samples.txt' % samples_dir)

GFiless = [None]*(n_scales+1)
Gss = [None]*(n_scales+1)
jacGFiless = [None]*(n_scales+1)
jacGss = [None]*(n_scales+1)

for i in range(n_scales+1):
    GFiless[i] = natsort.natsorted(glob('%s/scale_%i/G*.txt' % (samples_dir,i)))
    jacGFiless[i] = natsort.natsorted(glob('%s/scale_%i/jacG*.txt' % (samples_dir,i)))
    Gss[i] = [np.loadtxt(GFile) for GFile in GFiless[i]]
    if i == 0 or i == 1:
        jacGss[i] = [np.array([np.loadtxt(jacGFile)]) for jacGFile in jacGFiless[i]]
    else:
        jacGss[i] = [np.loadtxt(jacGFile) for jacGFile in jacGFiless[i]]

Ws = [None]*(n_scales+1)
ks = [None]*(n_scales+1)
W1s = [None]*(n_scales+1)
W2s = [None]*(n_scales+1)

#### ks and poly_orders by hand from calc_regr
#ks = [2,3,4,3,4,2,4,3,3,4,4]
#poly_orders = [3,3,3,3,3,3,3,3,3,3,3]
#
#for i in range(n_scales+1):
#    Ws[i] = np.loadtxt('%s/scale_%i/asm_eigVecs.txt' % (as_dir,i))
#    ks[i] = ks[i]
#    W1s[i] = Ws[i][:, :ks[i]]
#    W2s[i] = Ws[i][:, ks[i]:]
#    
print('\nenv for '+str(n)+' parameters and '+str(n_scales)+' scales\n')