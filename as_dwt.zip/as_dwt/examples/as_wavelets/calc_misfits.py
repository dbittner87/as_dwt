### Michael Engel ### 28.11.2019 ### calc_misfits.py ###
import env

import numpy as np
 
dir_misfits = env.dir_misfits

misfitGs = env.misfitGs
Gss = env.Gss
xs = env.xs

misfitss = [None]*(env.n_scales+1)
for i in range(env.n_scales+1):
    misfitss[i] = [misfitGs[i](Gss_) for Gss_ in Gss[i]]
    np.savetxt("%s/scale_%i/misfits.txt" % (dir_misfits,i), misfitss[i])