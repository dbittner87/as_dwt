import env
from uq_tools import asm
from plotters import summaryPlot2D, summaryPlot
 
import numpy as np
from sklearn import metrics

import matplotlib.pyplot as plt

### parameter to choose
r2level=0.7

polyorders = range(1,6)
ks = range(1, env.n+1)
ks = range(1, 11)

#xs = np.loadtxt('%s/xs.txt' % env.dir_misfits)
#misfits = np.loadtxt('%s/misfits_%.2f.txt' % (env.dir_misfits, env.noise_level))

#misfitGs = env.misfitGs
#Gss = env.Gss
xs = env.xs

misfits = [None]*(env.n_scales+1)
for i in range(env.n_scales+1):
#    misfits[i] = [misfitGs[i](Gss[i][k]) for k in range(len(Gss[i]))]
    misfits[i] = np.loadtxt('%s/scale_%i/misfits.txt'%(env.dir_misfits,i))

g_regrs = [[[None]*(env.n)]*len(polyorders)]*(env.n_scales+1)
r2_score = np.zeros([env.n_scales+1,len(polyorders),len(ks)])
for i in range(env.n_scales+1):
    print('\nscale %i' %i)
    misfits_i = misfits[i]
    for p in polyorders:
        for k in ks:
            W1 = env.Ws[i][:, :k]
        
            g_regrs[i][p-1][k-1] = asm.response_surface(xs, misfits_i, W1, poly_order=p)
            r2_score[i,p-1,k-1] = metrics.r2_score(misfits_i, g_regrs[i][p-1][k-1](np.dot(xs, W1)))
            print("scale: %i\torder: %i\tparameters: %i: %f" % (i,p,k, r2_score[i,p-1,k-1]))
            
plt.figure(figsize=((env.n_scales+1)*1,(env.n_scales+1)*3))
r2levelline=[None]*(env.n_scales+1)
for i in range(env.n_scales+1):
    plt.subplot(env.n_scales+1,1,i+1)
    r2levelline[i] = np.where(r2_score[i,:,:]<r2level,None,r2_score[i,:,:])
    #r2levelline[i] = np.where(r2levelline[i]!=None,1,None)
    plt.contourf(r2_score[i,:,:],levels=100)
    plt.contourf(r2levelline[i],levels=[0.7,1],colors=('r',),alpha=0.2,linestyles=(':',),linewidths=(2,))
    plt.xlabel('number of active parameters')
    plt.xticks(ticks=np.array(ks)-1,labels=ks)
    plt.ylabel('order of polynome')
    plt.yticks(ticks=np.array(polyorders)-1,labels=polyorders)
    plt.title('r2-score for scale %i'%i)
    plt.grid(True)
plt.subplots_adjust(left=0.1, bottom=0.05, right=0.9, top=0.95, wspace=0.6, hspace=0.4)
plt.savefig('r2scores',dpi=300)

plt.figure(figsize=((env.n_scales+1)*1,(env.n_scales+1)*3))
for i in range(env.n_scales+1):
#    plt.subplot(env.n_scales+1,1,i+1)
    w1 = env.Ws[i][:, :1]
    w2 = env.Ws[i][:, 1:2]
    w3 = env.Ws[i][:, 2:3]
    w4 = env.Ws[i][:, 3:4]
    values = misfits[i]
    
    w = w1

    fig = plt.figure()
    wTx = np.dot(xs, w)
    plt.scatter(wTx, values)
    plt.xlabel(r'$w_1^Tx$')
    plt.ylabel('Data misfit')
    plt.title('scale %i'%i)
#    fig, ax = summaryPlot(w1, xs, values, with_fit=True, poly_order=env.poly_orders[i])
    plt.show()
plt.subplots_adjust(left=0.1, bottom=0.05, right=0.9, top=0.95, wspace=0.6, hspace=0.4)
plt.savefig('surrogateplot',dpi=300)




def summaryPlot2D(w1, w2, xs, values, with_fit=False, poly_order=2):
    """
    Creates a 2D summary plot for specified directions.

    :param w1: First direction
    :param w2: Second direction
    :param xs: List of locations
    :param values: List of function values
    :param boolean with_fit: Show a regression fit
    :param integer poly_order: Polynomial order of the regression fit (only active if with_fit is True)
    """
    w1Tx = np.dot(xs, w1)
    w2Tx = np.dot(xs, w2)

    fig = plt.figure()
    plt.scatter(w1Tx, w2Tx, c=values)
    plt.colorbar()

    if with_fit:
        resp_surf = asm.response_surface(
            xs, values, np.transpose([w1, w2]), poly_order=poly_order)
        print("2D r2 score: %f" % metrics.r2_score(
            values, resp_surf(np.dot(xs, np.transpose([w1, w2])))))

        # y1s = np.arange(np.min(w1Tx), np.max(w1Tx), step=0.05)
        # y2s = np.arange(np.min(w2Tx), np.max(w2Tx), step=0.05)

        # fig, ax = plotSurface(y1s, y2s, resp_surf, alpha=0.3)

        fig = plt.figure()
        ax = plt.gca(projection='3d')
        X = np.arange(np.min(w1Tx), np.max(w1Tx), step=0.05)
        Y = np.arange(np.min(w2Tx), np.max(w2Tx), step=0.05)

        X, Y = np.meshgrid(X, Y)

        res = np.reshape(resp_surf(np.concatenate(
            [list(zip(x, y)) for x, y in zip(X, Y)])), np.shape(X))
        ax.plot_surface(X, Y, res, cmap=cm.coolwarm,
                        linewidth=0, antialiased=False, alpha=0.3)

        colors = np.abs(np.subtract(values, [resp_surf([[x, y]])[0]
                                             for x, y in zip(w1Tx, w2Tx)]))
        scatter = ax.scatter(w1Tx, w2Tx, values, c=colors)

        ax.set_zlim(np.min(values), np.max(values))
        ax.set_xlabel(r'$w_1^Tx$')
        ax.set_ylabel(r'$w_2^Tx$')
        ax.set_zlabel('Data misfit')
        fig.colorbar(scatter)

    return fig, ax