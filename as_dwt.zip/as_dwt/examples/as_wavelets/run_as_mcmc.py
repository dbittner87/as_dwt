import env
from uq_tools import asm
from uq_tools import mcmc

import numpy as np
import numpy.linalg as la
import numpy.random as rnd
import sys
import time as tm

import matplotlib.pyplot as plt

### Parameters to choose
#N = 10000
#stepsMCMC = 1 * 10**6
#burnin_actvar = 100000
#burnin_inactvar = 10000
#nPlotAccptRate = 5000
#nPlotAccptRate2 = 10000
#
#N = 100
#stepsMCMC = 1 * 10**4
#burnin_actvar = 1000
#burnin_inactvar = 100
#nPlotAccptRate = 5000
#nPlotAccptRate2 = 10000

N = 100
stepsMCMC = int(5e3)
burnin_actvar = 500
burnin_inactvar = 100
nPlotAccptRate = 200
nPlotAccptRate2 = 400

samplevariance = 0.05

### out of env
settings = env.settings

mcmc_dir = env.mcmc_dir

xs = env.xs

ks = env.ks
W1s = env.W1s
W2s = env.W2s
poly_orders = env.poly_orders


### mcmc for each scale
for i in range(3,4):#env.n_scales+1):
    print('\nscale %i'%i)
    k = ks[i]
    print('number of parameters: %i'%k)
    poly_order = poly_orders[i]
    print('order of polynome: %i\n'%poly_order)
    W1, W2 = W1s[i], W2s[i]
    
    
    if len(sys.argv) < 2:
        # Construct the response surface -----------------
        xs_misfit = xs
        misfits = np.loadtxt('%s/scale_%i/misfits.txt'%(env.dir_misfits,i))
    
        resp_surface = asm.response_surface(xs_misfit, misfits, W1, poly_order=poly_order)
        # ------------------------------------------------
    
        prior_y = asm.marginalPriorY(env.prior_sample(N=N), W1,
                                     kde_bandwidth=0.12, kde_kernel='gaussian')
    
        start = tm.time()
    
        y_samples = asm.as_mcmc_with_response_surface(
            resp_surface,
            W1, W2,
            proposal_sampler=lambda yk: rnd.normal(loc=yk, scale=samplevariance),#0.02),# scale=0.00275),### change scale -> larger
            priorY=prior_y,
            y1=np.zeros(k),
            steps=stepsMCMC,
            nPlotAccptRate=nPlotAccptRate)
    
        durat = tm.time() - start
    
#        burnin = settings.burnin_actvar
        burnin = burnin_actvar
        min_ess, ess, corr_times, acfs = mcmc.stats(
            y_samples, burnIn=burnin, maxlag=None)
        print("MCMC stats (min ess, ess, corr times): %f,%s,%s" % (min_ess, ess, corr_times))
    
        eff_y_samples = mcmc.pickEffSamples(y_samples, burnin, maxlag=None)
        print("# Eff. samples: %i" % len(eff_y_samples))
        print("Elapsed seconds: %f" % durat)
        print("# Eff. samples / sec: %f" % (len(eff_y_samples) / durat))
    
        np.savetxt('%s/scale_%i/y_samples_%id.txt' % (mcmc_dir,i,k), y_samples)
        np.savetxt('%s/scale_%i/eff_y_samples_%id.txt' % (mcmc_dir,i,k), eff_y_samples)
        np.savetxt('%s/scale_%i/y_autocorrs_%id.txt' % (mcmc_dir,i,k), acfs)
        exit()
    else:
        if sys.argv[1] == 'f':
            eff_y_samples = np.loadtxt('%s/scale_%i/eff_y_samples_%id.txt' %
                                       (mcmc_dir,i,k))[:, np.newaxis]
        else:
            print("Unknown argument '%s'" % sys.argv[1])
            exit()
    
    eff_y_samples = eff_y_samples[rnd.choice(len(eff_y_samples), 100)]
    
    start = tm.time()
    x_samples = asm.activeToOriginalMCMC(eff_y_samples,
                                         W1, W2,
                                         prior=env.prior,
                                         proposal_sampler=lambda zk: rnd.normal(
                                             loc=zk, scale=0.13),
                                         z1=np.zeros(env.n-k),
#                                         stepsPerActiveSample=1 * 10**5,
                                         stepsPerActiveSample=int(0.1*stepsMCMC),### check!!!
#                                         burnIn=settings.burnin_inactvar,
                                         burnIn = burnin_inactvar,
                                         nPlotAccptRate=nPlotAccptRate2)
    x_samples = np.concatenate(x_samples)
    print("%f sec elapsed." % (tm.time() - start))
    print('# of x samples: %i' % len(x_samples))
    
    np.savetxt('%s/scale_%i/x_samples_%id.txt' % (mcmc_dir,i,k), x_samples)
