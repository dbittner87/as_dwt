args = commandArgs(trailingOnly=TRUE)
id = args[1]
parameters = as.numeric(tail(args, -1))
print(parameters)

####################### Hydrotopes model ########################
#################################################################

#########################
### required packages ###
#########################

### install packages 
# install.packages("dplyr")
# install.packages("hydroGOF")

### load packages
library(dplyr)
library(hydroGOF) 

### select your working directory
setwd("C:/Users/danie/Documents/university/research/python_scripts/active_subspaces/code_daniel/examples/as_wavelets/scens/scen_main")

########################
### model parameters ###
########################

### Hydrotope 1 = Dolomite quarries (Hydrotop Nr. 222)
### Hydrotope 2 = Blaugras-Buchenwald (Hydrotop Nr. 301)
### Hydrotope 3 = Weissseggen-Buchenwald (Hydrotop Nr. 302)
### Hydrotope 4 = Schneerosen-Buchenwald (Hydrotop Nr. 303)

### snow model
f_melt <- 4               # melting factor
t_f    <- 0.5             # threshold temperature for snowmelt

### hydrotopes model
# Linear (baseflow) storage
k_b      <- 0.00043       # discharge coef for linear storage to spring

# Hydrotope 1
l_hyd_1  <- 0             # mean distance from hydrotope to spring
k_e_1    <- 0             # discharge coefficient quickflow Hyd1
e_min_1  <- 0             # e_min, deactivation threshold for transfer from system non-linear to the outlet
e_max_1  <- 1             # e_max, activation threshold for transfer from system non-linear to the outlet
alpha_1  <- 0
k_is_1   <- 0             # discharge coeficientf for inter-storage flow (gw recharge)
k_sec_1  <- 0.9           # discharge coeficientf for secondary springs flow
e_sec_1  <- 0             # e_sec, activation threshold for secondary springs

# Hydrotope 2 
l_hyd_2  <- 1600
k_e_2    <- parameters[1] / l_hyd_2
e_min_2  <- parameters[2]
e_max_2  <- parameters[3]
alpha_2  <- parameters[4]
k_is_2   <- parameters[5]
k_sec_2  <- parameters[6]
e_sec_2  <- parameters[7]

# Hydrotope 3 
l_hyd_3  <- 900
k_e_3    <- parameters[8] / l_hyd_3
e_min_3  <- parameters[9]
e_max_3  <- parameters[10]
alpha_3  <- parameters[11]
k_is_3   <- parameters[12]
k_sec_3  <- parameters[13]
e_sec_3  <- parameters[14]

# Hydrotope 4 
l_hyd_4  <- 960
k_e_4    <- parameters[15] / l_hyd_4
e_min_4  <- parameters[16]
e_max_4  <- parameters[17]
alpha_4  <- parameters[18]
k_is_4   <- parameters[19]
k_sec_4  <- parameters[20]
e_sec_4  <- parameters[21]

# spatial properties
area     <- 2.5 * 10^6  # space of total catchment in m2
hyd_1    <- 0.04        # % of tot catchment space covered by Hydrotope
hyd_2    <- 0.13
hyd_3    <- 0.56
hyd_4    <- 0.27

####################
### model set up ###
####################

# time step length in days
dt       <- 1    

# period of interest
#cal_p    <- c(1827, 2191) # 2006
#cal_p    <- c(2192, 2556) # 2007
#cal_p    <- c(2557, 2922) # 2008
#cal_p    <- c(1827, 2556) # 2006-2007
cal_p    <- c(1827, 2922) # 2006-2008
#cal_p    <- c(2192, 2922) # 2007-2008
#cal_p    <- c(4018, 4383) # 2012
#cal_p    <- c(4384, 4748) # 2013
#cal_p    <- c(4749, 5113) # 2014
#cal_p    <- c(5114, 5478) # 2015
#cal_p    <- c(5479, 5844) # 2016
#cal_p    <- c(1827, 4748) # 2013

######################
### initial values ###
######################

### snow model
S_s    <- 0
m_rate <- 0
S_tot  <- 0
melt   <- 0

### hydrotopes model
Q_tot    <- 35 * 86400
Q_is     <- 0
Q_b      <- 0
Q_e      <- 0
Q_sec    <- 0
E_b      <- 2900     # initial linear storage value
Q_b      <- 0        # initial baseflow value
E_1      <- 0        # initial storage value Hyd1
Q_e_1    <- 0        # initial quickflow value Hyd1
Q_is_1   <- 0        # initial interstorage flow (gw recharge) value Hyd 1
Q_sec_1  <- 0        # initial secondary springs flow value Hyd 1
E_2      <- 0        # initial storage value Hyd2
Q_e_2    <- 0        # initial quickflow value Hyd2
Q_is_2   <- 0        # initial interstorage flow (gw recharge) value Hyd 2
Q_sec_2  <- 0        # initial secondary springs flow value Hyd 2
E_3      <- 0        # initial storage value Hyd3
Q_e_3    <- 0        # initial quickflow value Hyd3
Q_is_3   <- 0        # initial interstorage flow (gw recharge) value Hyd 3
Q_sec_3  <- 0        # initial secondary springs flow value Hyd 3
E_4      <- 0        # initial storage value Hyd4
Q_e_4    <- 0        # initial quickflow value Hyd4
Q_is_4   <- 0        # initial interstorage flow (gw recharge) value Hyd 4
Q_sec_4  <- 0        # initial secondary springs flow value Hyd 4

######################################
### load input and evaluation data ###
######################################

kerschbaum      <- read.csv("kerschbaum.txt", header = T, sep = ";")
mean_T          <- read.csv("monthly_mean_temp.csv", header = T, sep = ";")
snow            <- read.csv("snow_waidhofen.csv", header = T, sep = ";")
kerschbaum$date <- as.POSIXct(kerschbaum$date, format = "%Y-%m-%d")
snow$date       <- as.POSIXct(snow$date, format = "%d.%m.%Y")

#####################################################
### ET model as introduced by Thornthwaite (1948) ### 
#####################################################

mean_T     <- mean_T$temperature
heat_index <- (mean_T/5)^1.514
heat_index[is.nan(heat_index)] <- 0
heat_index <- matrix(heat_index, nrow = 16)
heat_index <- rowSums(heat_index)
heat_index <- rep(heat_index, each = 12)

a          <- (0.000000675 * heat_index^3) - (0.000071 * heat_index^2) + 
  (0.01792 * heat_index) + 0.49239

pe         <- 16 * ((10 * mean_T) / heat_index)^a
pe[is.nan(pe)] <- 0

days       <- c(31,28,31,30,31,30,31,31,30,31,30,31)
days2      <- c(31,29,31,30,31,30,31,31,30,31,30,31)
days       <- c(days, days, days, days2, days, days, days, days2, days, days, days, 
                days2, days, days, days, days2)
pe         <- pe / days
x          <- seq(1,192,1)
rm(days, days2, a, heat_index, mean_T)

# linear interpolation of monthly ET values, setting each value 
# in the middle of each month (15th)
days1      <- c(15,31,28,31,30,31,30,31,31,30,31,30,31)
days       <- c(31,28,31,30,31,30,31,31,30,31,30,31)
days2      <- c(31,29,31,30,31,30,31,31,30,31,30,31)
days       <- c(days1, days, days, days2, days, days, days, days2, days, 
                days, days, days2, days, days, days, days2)
days       <- cumsum(days)
days       <- days[1:192]
interpol   <- seq(min(days), max(days), 1)
pe_daily   <- approx(days, pe, interpol)
pe_daily   <- pe_daily$y

pe_daily           <- data.frame(pe_daily, kerschbaum$date[15:(length(pe_daily)+14)])
colnames(pe_daily) <- c("pe_daily", "date")
kerschbaum         <- left_join(kerschbaum, pe_daily, by = "date") 
day                <- seq(1, length(kerschbaum$date), 1)
kerschbaum         <- data.frame(kerschbaum, day)
date               <- subset(kerschbaum, day %in% days)
kerschbaum$pe_daily[is.na(kerschbaum$pe_daily)] <- 0

rm(date, pe_daily, day, days, days1, days2, interpol, pe, x)

# calculating daily interception losses based on values given for beeches (11% winter, 17% summer) in  
# DVWK Merkblatt 238/1996
I_loss     <- c(0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.16, 0.15, 0.14, 0.13, 0.12)
I_loss     <- rep(I_loss, times = 16)
I_loss     <- c(I_loss, 0.11)
days1      <- c(1,31,28,31,30,31,30,31,31,30,31,30,31)
days       <- c(31,28,31,30,31,30,31,31,30,31,30,31)
days2      <- c(31,29,31,30,31,30,31,31,30,31,30,31)
days       <- c(days1, days, days, days2, days, days, days, days2, days, 
                days, days, days2, days, days, days, days2)
days       <- cumsum(days)
interpol   <- seq(min(days), max(days), 1)
I_daily    <- approx(days, I_loss, interpol)
I_daily    <- (I_daily$y[1:5844]) 
I_daily    <- I_daily * kerschbaum$precipitation_mm_d
I_daily[I_daily > 5] <- 5
S_a        <- kerschbaum$precipitation_mm_d[1:5844]
S_a        <- kerschbaum$precipitation_mm_d[1:length(S_a)] - I_daily[1:length(S_a)]
S_a2       <- kerschbaum$precipitation_mm_d[1:length(S_a)]


# Snow model and generation of source terms with interception
Temp   <- snow$temp_mitterlug[1:length(S_a)]

for(i in 1:length(Temp)){
  if(Temp[i] <= t_f){
    m_rate[i] <- 0
  }
  else{
    m_rate[i] <- f_melt * (Temp[i] - t_f)
  }
}

for(i in 1:length(Temp)){
  if(Temp[i] < t_f){
    melt[i]  <- 0
    S_s[i+1] <- S_s[i] + S_a[i + 1]
  }
  else if(S_s[i] >= m_rate[i]){
    melt[i]  <- m_rate[i]
    S_s[i+1] <- S_s[i] - m_rate[i]
  }
  else{
    melt[i]  <- S_s[i]
    S_s[i+1] <- 0
  }
}

for(i in 1:length(Temp)){
  if(Temp[i] < t_f){
    S_tot[i] <- 0
  }
  else if(melt[i] > 0){
    S_tot[i] <- melt[i] + S_a[i]
  }
  else{
    S_tot[i] <- S_a[i]
  }
}

# Snow model and generation of source terms without interception
S_s    <- 0
m_rate <- 0
S_tot2 <- 0
melt   <- 0

for(i in 1:length(Temp)){
  if(Temp[i] <= t_f){
    m_rate[i] <- 0
  }
  else{
    m_rate[i] <- f_melt * (Temp[i] - t_f)
  }
}

for(i in 1:length(Temp)){
  if(Temp[i] < t_f){
    melt[i]  <- 0
    S_s[i+1] <- S_s[i] + S_a2[i + 1]
  }
  else if(S_s[i] >= m_rate[i]){
    melt[i]  <- m_rate[i]
    S_s[i+1] <- S_s[i] - m_rate[i]
  }
  else{
    melt[i]  <- S_s[i]
    S_s[i+1] <- 0
  }
}

for(i in 1:length(Temp)){
  if(Temp[i] < t_f){
    S_tot2[i] <- 0
  }
  else if(melt[i] > 0){
    S_tot2[i] <- melt[i] + S_a2[i]
  }
  else{
    S_tot2[i] <- S_a2[i]
  }
}

rm(melt, m_rate, S_s, f_melt, days, days1, days2, interpol, I_loss)

###################################################
#### Rainfall-Runoff model incl. 4 Hydrotopes ##### 
###################################################

# Input data
Et       <- kerschbaum$pe_daily[1:length(S_a)]
S_tot1   <- S_tot2 - Et
S_tot2   <- S_tot  - Et
S_tot3   <- S_tot  - Et
S_tot4   <- S_tot  - Et

a_hyd1   <- area * hyd_1  # area of each hydrotope
a_hyd2   <- area * hyd_2
a_hyd3   <- area * hyd_3
a_hyd4   <- area * hyd_4

Q_obs    <- (kerschbaum$discharge_m3_d * 1000)

#############################################
### Model ###################################
#############################################

for(i in 1:length(S_a)){
  ### Storages ################################
  #############################################
  # non-linear, Hydrotop 1
  if((E_1[i] + (S_tot1[i] - ((Q_sec_1[i] + Q_is_1[i] + Q_e_1[i]) / a_hyd1)) * dt) >= 0){
    E_1[i+1] <- E_1[i] + (S_tot1[i] - ((Q_sec_1[i] + Q_is_1[i] + Q_e_1[i]) / a_hyd1)) * dt
  }
  else{
    E_1[i+1] <- 0
    S_tot1[i]    <- S_tot1[i] - (E_1[i] + (S_tot1[i] - ((Q_sec_1[i] + Q_is_1[i] + Q_e_1[i]) / 
                                                          a_hyd1)) * dt)
  }
  
  # non-linear, Hydrotop 2
  if((E_2[i] + (S_tot2[i] - ((Q_sec_2[i] + Q_is_2[i] + Q_e_2[i]) / a_hyd2)) * dt) >= 0){
    E_2[i+1] <- E_2[i] + (S_tot2[i] - ((Q_sec_2[i] + Q_is_2[i] + Q_e_2[i]) / a_hyd2)) * dt
  }
  else{
    E_2[i+1] <- 0
    S_tot2[i]    <- S_tot2[i] - (E_2[i] + (S_tot2[i] - ((Q_sec_2[i] + Q_is_2[i] + Q_e_2[i]) / 
                                                          a_hyd2)) * dt)
  }
  
  # non-linear, Hydrotop 3
  if((E_3[i] + (S_tot3[i] - ((Q_sec_3[i] + Q_is_3[i] + Q_e_3[i]) / a_hyd3)) * dt) >= 0){
    E_3[i+1] <- E_3[i] + (S_tot3[i] - ((Q_sec_3[i] + Q_is_3[i] + Q_e_3[i]) / a_hyd3)) * dt
  }
  else{
    E_3[i+1] <- 0
    S_tot3[i]    <- S_tot3[i] - (E_3[i] + (S_tot3[i] - ((Q_sec_3[i] + Q_is_3[i] + Q_e_3[i]) / 
                                                          a_hyd3)) * dt)
  }
  
  # non-linear, Hydrotop 4
  if((E_4[i] + (S_tot4[i] - ((Q_sec_4[i] + Q_is_4[i] + Q_e_4[i]) / a_hyd4)) * dt) >= 0){
    E_4[i+1] <- E_4[i] + (S_tot4[i] - ((Q_sec_4[i] + Q_is_4[i] + Q_e_4[i]) / a_hyd4)) * dt
  }
  else{
    E_4[i+1] <- 0
    S_tot4[i]    <- S_tot4[i] - (E_4[i] + (S_tot4[i] - ((Q_sec_4[i] + Q_is_4[i] + Q_e_4[i]) / 
                                                          a_hyd4)) * dt)
  }
  
  # linear (baseflow storage)
  E_b[i+1] <- E_b[i] + ((Q_is[i] - Q_b[i]) / area) * dt
  
  ### Flows ###################################
  #############################################
  # Q secondary springs, Hydrotop 1
  if(E_1[i+1] >= e_sec_1){
    Q_sec_1[i+1] <- k_sec_1 * a_hyd1 * (E_1[i+1] - e_sec_1)
  }
  else{
    Q_sec_1[i+1] <- 0 
  }
  
  # Q secondary springs, Hydrotop 2
  if(E_2[i+1] >= e_sec_2){
    Q_sec_2[i+1] <- k_sec_2 * a_hyd2 * (E_2[i+1] - e_sec_2)
  }
  else{
    Q_sec_2[i+1] <- 0 
  }
  
  # Q secondary springs, Hydrotop 3
  if(E_3[i+1] >= e_sec_3){
    Q_sec_3[i+1] <- k_sec_3 * a_hyd3 * (E_3[i+1] - e_sec_3)
  }
  else{
    Q_sec_3[i+1] <- 0 
  }
  
  ### Q secondary springs, Hydrotop 4
  if(E_4[i+1] >= e_sec_4){
    Q_sec_4[i+1] <- k_sec_4 * a_hyd4 * (E_4[i+1] - e_sec_4)
  }
  else{
    Q_sec_4[i+1] <- 0 
  }
  
  Q_sec[i+1] <- Q_sec_1[i+1] + Q_sec_2[i+1] + Q_sec_3[i+1] + Q_sec_4[i+1]
  
  ### Q inter-storage, Hydrotop 1
  Q_is_1[i+1] <- a_hyd1 * k_is_1 * E_1[i+1]
  
  ### Q inter-storage, Hydrotop 2
  Q_is_2[i+1] <- a_hyd2 * k_is_2 * E_2[i+1]
  
  ### Q inter-storage, Hydrotop 3
  Q_is_3[i+1] <- a_hyd3 * k_is_3 * E_3[i+1]
  
  ### Q inter-storage, Hydrotop 4
  Q_is_4[i+1] <- a_hyd4 * k_is_4 * E_4[i+1]
  
  ### total
  Q_is[i+1]   <- Q_is_1[i+1] + Q_is_2[i+1] + Q_is_3[i+1] + Q_is_4[i+1]
  
  
  
  ### Q baseflow
  Q_b[i+1] <- area * k_b * E_b[i+1]
  
  
  
  ### Hysteresis function, Hydrotop 1
  if(E_1[i+1] >= e_min_1 & Q_e_1[i] > 0){
    Q_e_1[i+1] <- (((E_1[i+1] - e_min_1)/(e_max_1 - e_min_1))^alpha_1) * k_e_1 * a_hyd1
  }
  else if(E_1[i+1] >= e_max_1 & Q_e_1[i] <= 0){
    Q_e_1[i+1] <- (((E_1[i+1] - e_min_1)/(e_max_1 - e_min_1))^alpha_1) * k_e_1 * a_hyd1
  }
  else{
    Q_e_1[i+1] <- 0 
  }
  
  ### Hysteresis function, Hydrotop 2
  if(E_2[i+1] >= e_min_2 & Q_e_2[i] > 0){
    Q_e_2[i+1] <- (((E_2[i+1] - e_min_2)/(e_max_2 - e_min_2))^alpha_2) * k_e_2 * a_hyd2
  }
  else if(E_2[i+1] >= e_max_2 & Q_e_2[i] <= 0){
    Q_e_2[i+1] <- (((E_2[i+1] - e_min_2)/(e_max_2 - e_min_2))^alpha_2) * k_e_2 * a_hyd2
  }
  else{
    Q_e_2[i+1] <- 0 
  }
  
  ### Hysteresis function, Hydrotop 3
  if(E_3[i+1] >= e_min_3 & Q_e_3[i] > 0){
    Q_e_3[i+1] <- (((E_3[i+1] - e_min_3)/(e_max_3 - e_min_3))^alpha_3) * k_e_3 * a_hyd3
  }
  else if(E_3[i+1] >= e_max_3 & Q_e_3[i] <= 0){
    Q_e_3[i+1] <- (((E_3[i+1] - e_min_3)/(e_max_3 - e_min_3))^alpha_3) * k_e_3 * a_hyd3
  }
  else{
    Q_e_3[i+1] <- 0 
  }
  
  ### Hysteresis function, Hydrotop 4
  if(E_4[i+1] >= e_min_4 & Q_e_4[i] > 0){
    Q_e_4[i+1] <- (((E_4[i+1] - e_min_4)/(e_max_4 - e_min_4))^alpha_4) * k_e_4 * a_hyd4
  }
  else if(E_4[i+1] >= e_max_4 & Q_e_4[i] <= 0){
    Q_e_4[i+1] <- (((E_4[i+1] - e_min_4)/(e_max_4 - e_min_4))^alpha_4) * k_e_4 * a_hyd4
  }
  else{
    Q_e_4[i+1] <- 0 
  }
  
  Q_e[i+1] <- Q_e_1[i+1] + Q_e_2[i+1] + Q_e_3[i+1] + Q_e_4[i+1]
  
  Q_tot[i+1] <- Q_e[i+1] + Q_b[i+1]
}

# subset data to calibration period
Q_b   <- Q_b[cal_p[1]:cal_p[2]]   / 86400
Q_e   <- Q_e[cal_p[1]:cal_p[2]]   / 86400
Q_sec <- Q_sec[cal_p[1]:cal_p[2]] / 86400
Q_is  <- Q_is[cal_p[1]:cal_p[2]]  / 86400
Q_tot <- Q_tot[cal_p[1]:cal_p[2]] / 86400
Q_obs <- Q_obs[cal_p[1]:cal_p[2]] / 86400
Q_e_1 <- Q_e_1[cal_p[1]:cal_p[2]] / 86400 / a_hyd1 
Q_e_2 <- Q_e_2[cal_p[1]:cal_p[2]] / 86400 / a_hyd2 
Q_e_3 <- Q_e_3[cal_p[1]:cal_p[2]] / 86400 / a_hyd3 
Q_e_4 <- Q_e_4[cal_p[1]:cal_p[2]] / 86400 / a_hyd4 
Q_is_1 <- Q_is_1[cal_p[1]:cal_p[2]] / 86400 / a_hyd1
Q_is_2 <- Q_is_2[cal_p[1]:cal_p[2]] / 86400 / a_hyd2
Q_is_3 <- Q_is_3[cal_p[1]:cal_p[2]] / 86400 / a_hyd3
Q_is_4 <- Q_is_4[cal_p[1]:cal_p[2]] / 86400 / a_hyd4
Q_sec_1 <- Q_sec_1[cal_p[1]:cal_p[2]] / 86400 / a_hyd1 
Q_sec_2 <- Q_sec_2[cal_p[1]:cal_p[2]] / 86400 / a_hyd2 
Q_sec_3 <- Q_sec_3[cal_p[1]:cal_p[2]] / 86400 / a_hyd3 
Q_sec_4 <- Q_sec_4[cal_p[1]:cal_p[2]] / 86400 / a_hyd4

E_1_1   <- E_1[cal_p[1]:cal_p[2]]
E_2_1   <- E_2[cal_p[1]:cal_p[2]] 
E_3_1   <- E_3[cal_p[1]:cal_p[2]]
E_4_1   <- E_4[cal_p[1]:cal_p[2]] 
E_b_1   <- E_b[cal_p[1]:cal_p[2]]

date    <- kerschbaum$date[cal_p[1]:cal_p[2]]

Q_mean  <- mean(Q_obs)

# output_flows <- data.frame(date,
#                            Q_tot, Q_e, Q_b, Q_is, Q_sec,
#                            Q_e_1, Q_e_2, Q_e_3, Q_e_4,
#                            Q_is_1, Q_is_2, Q_is_3, Q_is_4,
#                            Q_sec_1, Q_sec_2, Q_sec_3, Q_sec_4,
#                            E_1_1, E_2_1, E_3_1, E_4_1)
# colnames(output_flows) <- c("date", "Q_tot [ls-1]",
#                             "Q_e [ls-1]", "Q_b [ls-1]", "Q_is [ls-1]",
#                             "Q_sec [ls-1]", "Q_e_1 [ls-1m-2]", "Q_e_2 [ls-1m-2]",
#                             "Q_e_3 [ls-1m-2]", "Q_e_4 [ls-1m-2]", "Q_is_1 [ls-1m-2]",
#                             "Q_is_2 [ls-1m-2]", "Q_is_3 [ls-1m-2]", "Q_is_4 [ls-1m-2]",
#                             "Q_sec_1 [ls-1m-2]", "Q_sec_2 [ls-1m-2]", "Q_sec_3 [ls-1m-2]",
#                             "Q_sec_4 [ls-1m-2]", "E_1 [mm]", "E_2 [mm]", "E_3 [mm]", "E_4 [mm]")
# output_flows <- data.frame(Q_obs)
# colnames(output_flows) <- c('Q_obs [ls-1]')
output_flows <- data.frame(Q_tot)
colnames(output_flows) <- c("Q_tot [ls-1]")

write.table(output_flows, sprintf("../../model_output/output_%s.txt", id), sep = ";", row.names = F)

quit()

#############################################
### Statistics ##############################
############################################# 

# balance
hyd1_p <- a_hyd1*sum(S_tot1[(cal_p[1]):(cal_p[2])])
hyd2_p <- a_hyd2*sum(S_tot2[(cal_p[1]):(cal_p[2])])
hyd3_p <- a_hyd3*sum(S_tot3[(cal_p[1]):(cal_p[2])])
hyd4_p <- a_hyd4*sum(S_tot4[(cal_p[1]):(cal_p[2])])

hyd_p <- sum(hyd1_p, hyd2_p, hyd3_p, hyd4_p)

E_in_1 <- E_1[(cal_p[1])] * a_hyd1
E_in_2 <- E_2[(cal_p[1])] * a_hyd2
E_in_3 <- E_3[(cal_p[1])] * a_hyd3
E_in_4 <- E_4[(cal_p[1])] * a_hyd4
E_in_b <- E_b[(cal_p[1])] * area

E_in_tot <- sum(E_in_b, E_in_4, E_in_3, E_in_2, E_in_1)

input <- sum(hyd_p, E_in_tot) / 1000000

E_out_1 <- E_1[(cal_p[2])] * a_hyd1 
E_out_2 <- E_2[(cal_p[2])] * a_hyd2
E_out_3 <- E_3[(cal_p[2])] * a_hyd3
E_out_4 <- E_4[(cal_p[2])] * a_hyd4
E_out_b <- E_b[(cal_p[2])] * area

E_out_tot <- sum(E_out_b, E_out_4, E_out_3, E_out_2, E_out_1)

E1_diff <- (E_1[(cal_p[2])] - E_1[(cal_p[1])]) * a_hyd1
E2_diff <- (E_2[(cal_p[2])] - E_2[(cal_p[1])]) * a_hyd2
E3_diff <- (E_3[(cal_p[2])] - E_3[(cal_p[1])]) * a_hyd3
E4_diff <- (E_4[(cal_p[2])] - E_4[(cal_p[1])]) * a_hyd4
Eb_diff <- (E_b[(cal_p[2])] - E_b[(cal_p[1])]) * area

E_diff_tot <- sum(E1_diff, E2_diff, E3_diff, E4_diff, Eb_diff)

Q_sec_tot <- Q_sec * 86400
Q_sec_tot <- sum(Q_sec_tot)
Q_tot_tot <- Q_tot * 86400
Q_tot_tot <- sum(Q_tot_tot)

output <- -(sum(Q_sec_tot, Q_tot_tot, E_out_tot)) / 1000000

balance <- input + output

NSE <- NSE(Q_tot, Q_obs)
MAE <- sum(abs(Q_tot - Q_obs)) / length(Q_tot)

water_balance <- data.frame(input, output, balance, NSE, MAE)
colnames(water_balance) <- c("TOT_IN [m3]", "TOT_OUT [m3]", 
                             "BALANCE [m3]", "NSE [-]", "MAE [ls-1]")

write.table(water_balance, sprintf("../../model_output/balance%s.txt", id), sep = ";", row.names = F)
