### Michael Engel ### 03.07.2019 ### watrans.py ###

###############################################################################
# Discrete Wavelet Transform for periodized signals:
# it returns and plots the parameters up to the chosen maximum depth and gives
# an error measure with respect to a reference signal (e.g. measurements)
###############################################################################
# it requires the numpy, matplotlib, copy and pywt library which have to be installed
# with pip beforehand
###############################################################################
# INPUT
# signal
# motherfct
# maxlevel
# dt (opt)
# unit (opt)
# skill (opt)               -   decide whether you want to do the decomposition
#                               up to the chosen level no matter what effects
#                               come along with it: 'I know what I do!'
###############################################################################

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import pywt
import pywt._doc_utils as doc
import copy

class Watrans:
    ### initialize
    def __init__ (self, signal, motherfct, maxlevel, dt = 1, unit = 's', skill = 'bla'):
        print('\n### create watrans object ###\n')
        self.signal = signal
        self.motherfct = motherfct
        self.maxlevel = maxlevel
        self.dt = dt
        self.unit = unit
        
        maxi = pywt.dwt_max_level(len(self.signal), self.motherfct)
        if skill != 'I know what I am doing!' and maxi < self.maxlevel:
            print('Chosen maximum decomposition level is to high!\nThe level is set from '+str(maxlevel)+' to '+str(maxi)+'.')
            self.maxlevel = maxi
        
        #norm signal
        self.mu = np.mean(self.signal)
        self.sigma = np.std(self.signal)
        self.signal_normed = (self.signal-self.mu)/self.sigma
        
        #compute wavelet coefficients
        self.coeff = pywt.wavedec(self.signal_normed, self.motherfct, mode = 'zero', level = self.maxlevel)
        
        #compute signals for each level
        self.signal_normed_level = [self.signal_normed]
        for i in range(0,self.maxlevel+1):
            coeff_level = copy.deepcopy(self.coeff)
            for j in range(0,self.maxlevel+1):
                if j != i:
                    coeff_level[j] = np.zeros_like(coeff_level[j])
            self.signal_normed_level.append(pywt.waverec(coeff_level,self.motherfct, mode = 'zero'))
        
        #pad signal like chosen mode        
        self.signal_padded = doc.pad(self.signal_normed, len(signal), 'zeros')
        
        self.frq = pywt.scale2frequency(self.motherfct,range(1,self.maxlevel+1))/self.dt
        self.frq = self.frq.tolist()
        self.frq.append(str(unit))
        self.frq.append(1/self.dt)
        self.frq = self.frq[::-1]
        
        self.signal_frq = [self.signal_normed_level,self.frq]
        
        print('\n### watrans object created ###\n')
        pass
              
    ### methods
    def coeff(self):
        return [self.coeff,self.frq[1:]]
    
    def levelS(self):
        return self.signal_frq
    
    def frqlevelS(self, frq_desired):
        frq_signal_frq = [self.signal_normed_level[0:2],self.frq[0:2]]
        for j in range(0,len(frq_desired)):
            frq_signal_frq[0].append(np.zeros(len(self.signal_normed)))
            frq_signal_frq[1].append(frq_desired[j])
            for i in range(2,len(self.signal_normed_level)):
                if j == 0:
                    if self.frq[i]<=frq_desired[j]:
                        frq_signal_frq[0][j+2] = frq_signal_frq[0][j+2]+self.signal_normed_level[i]
                else:    
                    if self.frq[i]<=frq_desired[j] and self.frq[i]> frq_desired[j-1]:
                        frq_signal_frq[0][j+2] = frq_signal_frq[0][j+2]+self.signal_normed_level[i]
        for i in range(2,len(self.signal_normed_level)):            
            if len(frq_signal_frq[0]) == len(frq_desired)+2 and self.frq[i]>frq_desired[-1]:
                frq_signal_frq[0].append(np.zeros(len(self.signal_normed)))
                frq_signal_frq[1].append('>'+str(frq_desired[-1]))
            elif self.frq[i]>frq_desired[-1]:
                frq_signal_frq[0][-1] = frq_signal_frq[0][-1]+self.signal_normed_level[i]
        return frq_signal_frq
    
    def plot(self, levelSfrq = None, save = None, dpi = 300):
        if levelSfrq == None:
            signal = self.signal_frq
            maxl = self.maxlevel
        else:
            if len(levelSfrq)!=2 or len(levelSfrq[0])<3 or len(levelSfrq[1])!=len(levelSfrq[0]):
                print('\n### Watrans.plot: wrong input ###\n')
                pass
            signal = levelSfrq
            maxl = len(levelSfrq[0])-2
        
        plt.figure(figsize = (4,(maxl+2)*3))
        matplotlib.rcParams.update({'font.size': 12})
        
        plt.subplot(maxl+2,1,1, title='normed signal')
        plt.plot(signal[0][0],'b')
        plt.xlabel('k')
        plt.ylabel('$A_k$')
        
        plt.subplot(maxl+2,1,2, title='signal for approximation coefficients')
        plt.plot(signal[0][1],'b', linewidth = 0.5)
        plt.xlabel('$k$')
        plt.ylabel('$\u0394A_{k,approximation}$')
        plt.grid(True)
        
        for i in range(2,maxl+2):
            plt.subplot(maxl+2,1,i+1, title = 'Signal for level '+str(i-1)+'\n$'+str(signal[1][i])+'  [1/'+signal[1][1]+']$')
            plt.plot(signal[0][i],'b', linewidth = 0.5)
            plt.xlabel('$k$')
            plt.ylabel('$A_{k,'+str(i-1)+'}$')
            plt.grid(True)
        plt.subplots_adjust(left=0.2, bottom=0.05, right=0.8, top=0.95, wspace=0.6, hspace=0.8)
        
        if save != None:
            plt.savefig(str(save), dpi = dpi)
    
        plt.show()
        pass
        
    ### comparison methods
    def compare(self, watransobj, maxlevel = None, dt = None, unit = None):
        pass
        
    ### delete
    def __del__(self):
        print('\n### watrans object deleted ###\n')
        pass