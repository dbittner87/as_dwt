### Michael Engel ### 07.07.2019 ### padded.py

import numpy as np

def padded (signal, length, values, style):
    if style == 'constant':
        if len(signal)<length:
            signal_padded = np.pad(signal,(int(np.floor((length-len(signal))/2)),length-len(signal)-int(np.floor((length-len(signal))/2))),'constant', constant_values = values)
        elif len(signal) == length:
            signal_padded = signal
        else:
            print('### padded: signal longer than desired length -> change desired length ###')
            return 0
        
    elif style == 'linear':
        if len(signal)<length:
            signal_padded = np.pad(signal,(int(np.floor((length-len(signal))/2)),length-len(signal)-int(np.floor((length-len(signal))/2))),'linear_ramp', end_values = values)
        elif len(signal) == length:
            signal_padded = signal
        else:
            print('### padded: signal longer than desired length -> change desired length ###')
            return 0
        
    elif style == 'mean':
        if len(signal)<length:
            signal_padded = np.pad(signal,(int(np.floor((length-len(signal))/2)),length-len(signal)-int(np.floor((length-len(signal))/2))),'mean')
        elif len(signal) == length:
            signal_padded = signal
        else:
            print('### padded: signal longer than desired length -> change desired length ###')
            return 0
        
    elif style == 'cubic':
        if len(signal)<length:
            fun  = lambda x, r0, v0: np.multiply((-2*(r0-v0)),np.power(x,3)) + np.multiply((3*(r0-v0)),np.power(x,2)) + v0
            signal_padded = np.append(fun(np.linspace(0,1,int(np.floor((length-len(signal))/2))),signal[0],values[0]),np.array(signal))
            signal_padded = np.append(signal_padded, fun(np.linspace(0,1,length-len(signal)-int(np.floor((length-len(signal))/2))),values[1],signal[-1]))
        elif len(signal) == length:
            signal_padded = signal
        else:
            print('### padded: signal longer than desired length -> change desired length ###')
            return 0
        
    else:
        print('### padded: no proper style ###')
        return 0
    return signal_padded